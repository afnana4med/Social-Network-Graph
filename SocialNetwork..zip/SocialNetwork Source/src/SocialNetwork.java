import java.util.ArrayList;
import java.util.Arrays;
import java.util.*;

public class SocialNetwork extends DiGraph {
    public SocialNetwork() {
        super(Names.networkMembers.length);
    }

    DiGraph graph = new DiGraph(Names.networkMembers.length);


    /**
     * COMPLETE THIS METHOD
     * takes the name of a person and should return an ArrayList of String objects, which contains
     * the names all the followers of person.
     *
     * @param person - the name of the Person to check
     * @return
     */
    public ArrayList<String> broadcastsTo(String person) {
        // creating new array list to store the names of followers
        ArrayList<String> whoFollows = new ArrayList<>();
        // performs a search for the index of a given person in the Names.networkMembers array
        int listOfPerson = Arrays.asList(Names.networkMembers).indexOf(person);

        // validation to check if person in the list or not
        if (listOfPerson == -1) {
            System.out.println("Person not found in the network: " + person);
            return whoFollows;
        }

        // Use a while loop to check if 'listOfPerson' has any followers or any edge next
        int i = 0;
        boolean hasEdge = false;
        while (i < Names.networkMembers.length && !hasEdge) {
            if (hasEdge(i, listOfPerson)) {
                hasEdge = true;
            }
            i = i + 1;
        }

        // If no followers of that person
        if (!hasEdge) {
            System.out.println(person + " has no followers.");
            return whoFollows;
        }

        // Iterate through all list and add followers to which msg is broadcast
        for (int j = 0; j < Names.networkMembers.length; j++) {
            if (hasEdge(j, listOfPerson)) {
                whoFollows.add(Names.networkMembers[j]);
            }
        }
        // return arraylist of name of followers
        return whoFollows;
    }

    /**
     * COMPLETE THIS METHOD
     * Method takes the name of a person starting a broadcasting a story (source) and the name of the person that the
     * story is broadcast to (target).
     * It uses the refactored depth first search to see if the story will get from the source to the target and
     * should return true if the story will get from the source to the target
     * and false if there is no path from the source to the target.
     *
     * @param source - the name of the Person to check
     * @param target - the name of the target to check
     * @return true if the story will get from the source to the target and false if there is no path from the
     * source to the target.
     */
    public boolean canReach(String source, String target) {
        // performs a search for the sourceIndex of a given person in the Names.networkMembers array
        int sourceIndex = Arrays.asList(Names.networkMembers).indexOf(source);
        // performs a search for the targetIndex of a given person in the Names.networkMembers array
        int targetIndex = Arrays.asList(Names.networkMembers).indexOf(target);

        // if person is not in the list
        if (sourceIndex == -1 || targetIndex == -1) {
            return false;
        }

        // Use the provided DFS method to check if there is a path from 'source' to 'target'
        return Traversal.DFS(adjacencyList, sourceIndex, targetIndex);
    }

    /**
     * COMPLETE THIS METHOD
     * Method takes the name of a person who has started a story and uses a breadth first search to return an
     * ArrayList of String objects that contains the names of all the person who will receive the story
     * broadcast by that person.
     *
     * @param person name of the person to check
     * @return an ArrayList of String objects that contains the names of all the person who will receive the story
     */
    public ArrayList<String> receiversOf(String person) {
        // initialise -1 as nothing in the list
        int listOfPerson = -1;
        // iterate over the list
        for (int i = 0; i < Names.networkMembers.length; i++) {
            if (Names.networkMembers[i].equals(person)){
                listOfPerson = i;
                break;
            }
        }
        return Traversal.BFS(adjacencyList, listOfPerson);
    }
}
