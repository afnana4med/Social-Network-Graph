import java.util.ArrayList;
import java.util.LinkedList;
import java.util.*;
import java.util.Queue;

public class Traversal {
    /**
     * REFACTOR THIS METHOD
     * Perform a BFS traversal of the graph, printing the nodes in the order visited
     *
     * @return
     */
    public static ArrayList<String> BFS(ArrayList<Integer>[] adjList, Integer startNode) {
        //create the list of visited nodes and the queue
        Queue<Integer> theQueue = new LinkedList<>();
        // creating new array of type boolean
        boolean[] visitedNode = new boolean[adjList.length];
        // creating new arraylist to store receiver names of type string
        ArrayList<String> receiveTo = new ArrayList<>();

        // set start as true and add this to queue
        visitedNode[startNode] = true;
        theQueue.add(startNode);

        // do until queue is empty
        while (!theQueue.isEmpty()) {
            // remove the front element from queue
            Integer listOfPerson = (Integer) theQueue.remove();

            // iterate to get the next person from adj list
            for (Integer neighbour : adjList[listOfPerson]) {
                if (!visitedNode[neighbour]) {
                    visitedNode[neighbour] = true;

                    // add next person to queue
                    theQueue.add(neighbour);

                    // add next person to receiver list
                    receiveTo.add(Names.networkMembers[neighbour]);
                }
            }
        }
        // return name of person
        return receiveTo;
    }

    /**
     * REFACTOR THIS METHOD
     * Perform a DFS traversal of the graph
     * The refactored method will return true if the destinationNode is encountered in the subgraph descending from
     * startNode
     */

    // refactor
    public static boolean DFS(ArrayList<Integer>[] adjList, Integer startNode, Integer destinationNode) {

        // creating new array list to store list of visited people
        ArrayList<Integer> visitedNodes = new ArrayList<>();
        Stack theStack = new ArrayStack();

        // mark first node as visited and push in stack
        visitedNodes.add(startNode);
        theStack.push(startNode);

        // do until stack is empty
        while (!theStack.isEmpty()) {

            Integer item = (Integer) theStack.pop();
            // return true if pop item is equal to destination node
            if (item.equals(destinationNode)) {
                return true;
            }
            // iterate over list
            for (Integer neighbour : adjList[item]) {
                // if neighbour is not visited mark them as visited and push in stack
                if (!visitedNodes.contains(neighbour)) {
                    visitedNodes.add(neighbour);
                    theStack.push(neighbour);
                }
            }
        }
        // if destination node is not found
        return false;
    }
}